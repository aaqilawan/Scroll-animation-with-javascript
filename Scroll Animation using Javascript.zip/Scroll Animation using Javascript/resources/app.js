function Apper() {
    let introText = document.querySelector('.intro-text');
    let introPosition = introText.getBoundingClientRect().top;
    let introHeight = window.innerHeight / 1.4;

    if (introPosition < introHeight) {
        introText.classList.add('intro-apper');
    }
}

window.addEventListener('scroll', Apper);